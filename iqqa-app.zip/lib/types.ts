export type Category = "Fatal" | "Non Fatal"

export interface CriteriaRow {
  id: string
  criteria: string
  category: Category
  weightage: number
}

export interface Analysis {
  executiveName: string
  callDuration: string
  criteria: CriteriaRow[]
}

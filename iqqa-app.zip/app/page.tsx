import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import UploadSection from "@/components/iqqa/upload-section"

export default function Page() {
  return (
    <main className="font-sans min-h-dvh bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto max-w-5xl px-4 py-6">
          <h1 className="text-2xl md:text-3xl font-semibold text-balance">iQQA - Intelligent call quality analysis</h1>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 py-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Upload your conversation here :</CardTitle>
          </CardHeader>
          <CardContent>
            <UploadSection />
          </CardContent>
        </Card>
      </section>
    </main>
  )
}

import { NextResponse } from "next/server"
import type { Analysis, CriteriaRow } from "@/lib/types"

export async function POST(req: Request) {
  try {
    // Parse the incoming form data to simulate a real upload (file not used in this mock)
    await req.formData()

    const rows: CriteriaRow[] = [
      { id: "1", criteria: "Uses appropriate greeting", category: "Non Fatal", weightage: 2 },
      { id: "2", criteria: "Obtains and verifies customer contact information", category: "Fatal", weightage: 1 },
      { id: "3", criteria: "Understood and clarified the issue", category: "Non Fatal", weightage: 4 },
      { id: "4", criteria: "Used proper grammar & terms", category: "Non Fatal", weightage: 4 },
      { id: "5", criteria: "Speak clearly and audibly", category: "Fatal", weightage: 1 },
      { id: "6", criteria: "Executive enthusiastic in the call", category: "Non Fatal", weightage: 3 },
      { id: "7", criteria: "Executive empathetic to the Customer in the call", category: "Non Fatal", weightage: 4 },
      { id: "8", criteria: "Executive take ownership of call.", category: "Fatal", weightage: 1 },
      { id: "9", criteria: "Call duration suitable", category: "Non Fatal", weightage: 2 },
      {
        id: "10",
        criteria: "Customer confirm the resolution / expressed satisfaction.",
        category: "Non Fatal",
        weightage: 2,
      },
      { id: "11", criteria: "Appropriately use of hold/Dead air", category: "Fatal", weightage: 1 },
      { id: "12", criteria: "Checked /triaged and proper probing", category: "Non Fatal", weightage: 3 },
      { id: "13", criteria: "Followed correct procedure", category: "Fatal", weightage: 1 },
      { id: "14", criteria: "Shared the reference number of the call", category: "Non Fatal", weightage: 2 },
      { id: "15", criteria: "Offered Additional help before closing the call", category: "Non Fatal", weightage: 2 },
    ]

    const payload: Analysis = {
      executiveName: "Anita",
      callDuration: "3 min 22 sec",
      criteria: rows,
    }

    return NextResponse.json(payload)
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}

import { NextResponse } from "next/server"
import type { Analysis } from "@/lib/types"

export async function POST(req: Request) {
  try {
    const data = (await req.json()) as Analysis
    // Persist to your database here if needed.
    return NextResponse.json({ ok: true, data })
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 })
  }
}

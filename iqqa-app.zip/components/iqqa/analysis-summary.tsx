"use client"
import { Label } from "@/components/ui/label"

export default function AnalysisSummary({
  executiveName,
  callDuration,
  editable,
  onChange,
}: {
  executiveName: string
  callDuration: string
  editable: boolean
  onChange: (next: { executiveName?: string; callDuration?: string }) => void
}) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="grid gap-1.5">
        <Label className="text-muted-foreground">
          Name of the Executive: <span className="font-medium text-foreground">{executiveName}</span>
        </Label>
      </div>
      <div className="grid gap-1.5">
        <Label className="text-muted-foreground">
          Call Duration: <span className="font-medium text-foreground">{callDuration}</span>
        </Label>
      </div>
    </div>
  )
}

"use client"

import React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import AnalysisSummary from "./analysis-summary"
import CriteriaTable from "./criteria-table"
import type { Analysis, CriteriaRow } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

export default function UploadSection() {
  const [file, setFile] = React.useState<File | null>(null)
  const [uploading, setUploading] = React.useState(false)
  const [progress, setProgress] = React.useState(0)
  const [analysis, setAnalysis] = React.useState<Analysis | null>(null)
  const [isEditing, setIsEditing] = React.useState(false)
  const { toast } = useToast()

  const isUploadDisabled = !file || uploading

  async function handleUpload() {
    if (!file) return
    setUploading(true)
    setProgress(0)

    const interval = setInterval(() => {
      setProgress((p) => (p < 90 ? p + 10 : p))
    }, 250)

    try {
      const form = new FormData()
      form.append("conversation", file)
      const res = await fetch("/api/analyze", { method: "POST", body: form })
      if (!res.ok) throw new Error("Failed to analyze the conversation")
      const data = (await res.json()) as Analysis
      setAnalysis(data)
      setProgress(100)
      toast({ title: "Analysis complete", description: "Your call analysis is ready." })
    } catch (err: any) {
      toast({
        title: "Upload failed",
        description: err?.message ?? "Something went wrong.",
        variant: "destructive",
      })
    } finally {
      clearInterval(interval)
      setUploading(false)
      setTimeout(() => setProgress(0), 600)
    }
  }

  function updateRow(updated: CriteriaRow) {
    if (!analysis) return
    setAnalysis({
      ...analysis,
      criteria: analysis.criteria.map((r) => (r.id === updated.id ? updated : r)),
    })
  }

  async function handleSave() {
    if (!analysis) return
    try {
      const res = await fetch("/api/save-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(analysis),
      })
      if (!res.ok) throw new Error("Failed to save analysis")
      toast({ title: "Saved", description: "Your analysis was saved successfully." })
      setIsEditing(false)
    } catch (err: any) {
      toast({
        title: "Save failed",
        description: err?.message ?? "Something went wrong.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="grid gap-4 md:grid-cols-[1fr_auto] md:items-end">
        <div className="grid gap-2">
          
          <Input
            id="conversation"
            type="file"
            accept=".mp3,.wav,.m4a,.mp4,.txt,.pdf"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
        </div>
        <Button
          type="button"
          onClick={handleUpload}
          disabled={isUploadDisabled}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          Upload
        </Button>
      </div>

      {uploading && (
        <div className="rounded-md border bg-card p-4 text-sm">
          <p className="font-medium">Upload in progress.. please wait</p>
          <div className="mt-3 h-2 w-full overflow-hidden rounded bg-muted" aria-label="Upload progress">
            <div
              className="h-2 rounded bg-green-600 transition-all"
              style={{ width: `${progress}%` }}
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={progress}
            />
          </div>
        </div>
      )}

      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg md:text-xl">Detailed analysis of your call</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <AnalysisSummary
              executiveName={analysis.executiveName}
              callDuration={analysis.callDuration}
              editable={isEditing}
              onChange={(next) => setAnalysis((a) => (a ? { ...a, ...next } : a))}
            />

            <div className="space-y-2">
              <h3 className="text-base font-semibold">Analyzed Summary Of The Conversation<br></h3>
              <CriteriaTable rows={analysis.criteria} editable={isEditing} onRowChange={updateRow} />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsEditing((v) => !v)}>
                {isEditing ? "Stop Editing" : "Edit"}
              </Button>
              <Button type="button" onClick={handleSave} className="bg-green-600 hover:bg-green-700 text-white">
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

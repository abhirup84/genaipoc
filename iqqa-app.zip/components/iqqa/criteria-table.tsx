"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import type { CriteriaRow } from "@/lib/types"
import { cn } from "@/lib/utils"

export default function CriteriaTable({
  rows,
  editable,
  onRowChange,
}: {
  rows: CriteriaRow[]
  editable: boolean
  onRowChange: (row: CriteriaRow) => void
}) {
  const totalWeightage = rows.reduce((sum, row) => sum + row.weightage, 0)

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[55%]">Call quality criteria</TableHead>
            <TableHead className="w-[25%]">Proposed Category</TableHead>
            <TableHead className="w-[20%] text-right">Proposed Weightage</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => {
            const categoryColor = row.category === "Fatal" ? "text-red-600" : "text-teal-700"
            return (
              <TableRow key={row.id}>
                <TableCell>
                  <span className="text-foreground font-normal">{row.criteria}</span>
                </TableCell>

                <TableCell>
                  <span className={cn("font-medium", categoryColor)}>{row.category}</span>
                </TableCell>

                <TableCell className="text-right">
                  {editable ? (
                    <Input
                      inputMode="numeric"
                      type="number"
                      min={0}
                      value={row.weightage}
                      onChange={(e) => onRowChange({ ...row, weightage: Number(e.target.value) })}
                      aria-label="Proposed Weightage"
                      className="text-right"
                    />
                  ) : (
                    <span className="text-foreground">{row.weightage}</span>
                  )}
                </TableCell>
              </TableRow>
            )
          })}
          <TableRow className="border-t-2 border-gray-300 bg-gray-50">
            <TableCell className="font-semibold">Total</TableCell>
            <TableCell></TableCell>
            <TableCell className="text-right font-semibold text-lg">{totalWeightage}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  )
}

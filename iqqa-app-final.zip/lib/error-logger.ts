interface ErrorLogEntry {
  id: string
  timestamp: string
  level: "error" | "warn" | "info" | "debug"
  message: string
  stack?: string
  context?: Record<string, any>
  userAgent?: string
  url?: string
  userId?: string
}

class ErrorLogger {
  private logs: ErrorLogEntry[] = []
  private maxLogs = 1000 // Keep last 1000 logs in memory

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  }

  private createLogEntry(
    level: ErrorLogEntry["level"],
    message: string,
    error?: Error,
    context?: Record<string, any>,
  ): ErrorLogEntry {
    return {
      id: this.generateId(),
      timestamp: new Date().toISOString(),
      level,
      message,
      stack: error?.stack,
      context,
      userAgent: typeof window !== "undefined" ? window.navigator.userAgent : undefined,
      url: typeof window !== "undefined" ? window.location.href : undefined,
    }
  }

  private addLog(entry: ErrorLogEntry) {
    this.logs.unshift(entry)

    // Keep only the most recent logs
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(0, this.maxLogs)
    }

    // Console output for development
    if (process.env.NODE_ENV === "development") {
      const consoleMethod = entry.level === "error" ? "error" : entry.level === "warn" ? "warn" : "log"
      console[consoleMethod](`[${entry.level.toUpperCase()}] ${entry.message}`, {
        timestamp: entry.timestamp,
        stack: entry.stack,
        context: entry.context,
      })
    }

    // In production, you could send to external logging service
    if (process.env.NODE_ENV === "production") {
      this.sendToExternalService(entry)
    }
  }

  private async sendToExternalService(entry: ErrorLogEntry) {
    // Placeholder for external logging service integration
    // Could integrate with Sentry, LogRocket, DataDog, etc.
    try {
      // Example: await fetch('/api/external-logs', { method: 'POST', body: JSON.stringify(entry) })
    } catch (err) {
      // Silently fail to avoid infinite loops
    }
  }

  error(message: string, error?: Error, context?: Record<string, any>) {
    this.addLog(this.createLogEntry("error", message, error, context))
  }

  warn(message: string, context?: Record<string, any>) {
    this.addLog(this.createLogEntry("warn", message, undefined, context))
  }

  info(message: string, context?: Record<string, any>) {
    this.addLog(this.createLogEntry("info", message, undefined, context))
  }

  debug(message: string, context?: Record<string, any>) {
    this.addLog(this.createLogEntry("debug", message, undefined, context))
  }

  getLogs(level?: ErrorLogEntry["level"], limit = 100): ErrorLogEntry[] {
    let filteredLogs = this.logs

    if (level) {
      filteredLogs = this.logs.filter((log) => log.level === level)
    }

    return filteredLogs.slice(0, limit)
  }

  clearLogs() {
    this.logs = []
  }

  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2)
  }
}

// Singleton instance
export const errorLogger = new ErrorLogger()

// Convenience functions
export const logError = (message: string, error?: Error, context?: Record<string, any>) => {
  errorLogger.error(message, error, context)
}

export const logWarn = (message: string, context?: Record<string, any>) => {
  errorLogger.warn(message, context)
}

export const logInfo = (message: string, context?: Record<string, any>) => {
  errorLogger.info(message, context)
}

export const logDebug = (message: string, context?: Record<string, any>) => {
  errorLogger.debug(message, context)
}

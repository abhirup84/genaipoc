import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import UploadSection from "@/components/iqqa/upload-section"
import Image from "next/image"

export default function Page() {
  return (
    <main className="font-sans min-h-dvh bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Image
                src="/images/tcs-logo.png"
                alt="TCS - Tata Consultancy Services"
                width={120}
                height={40}
                className="h-8 w-auto sm:h-10 md:h-12"
                priority
              />
              <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold text-balance">
                iQQA - Intelligent Call Quality Analyzer
              </h1>
            </div>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <Card>
          <CardHeader className="pb-4 sm:pb-6">
            <CardTitle className="text-base sm:text-lg md:text-xl">Upload your conversation here :</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <UploadSection />
          </CardContent>
        </Card>
      </section>
    </main>
  )
}

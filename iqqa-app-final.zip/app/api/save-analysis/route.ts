import { NextResponse } from "next/server"
import type { Analysis } from "@/lib/types"
import { logError, logInfo } from "@/lib/error-logger"

export async function POST(req: Request) {
  try {
    const data = (await req.json()) as Analysis

    logInfo("Analysis save request received", {
      executiveName: data.executiveName,
      criteriaCount: data.criteria?.length,
    })

    // Persist to your database here if needed.

    logInfo("Analysis saved successfully", {
      executiveName: data.executiveName,
    })

    return NextResponse.json({ ok: true, data })
  } catch (error) {
    logError("Failed to save analysis", error as Error, {
      endpoint: "/api/save-analysis",
      method: "POST",
    })
    return NextResponse.json({ ok: false }, { status: 400 })
  }
}

import { NextResponse } from "next/server"
import { errorLogger } from "@/lib/error-logger"

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const level = searchParams.get("level") as "error" | "warn" | "info" | "debug" | null
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const format = searchParams.get("format") || "json"

    const logs = errorLogger.getLogs(level || undefined, limit)

    if (format === "export") {
      const exportData = errorLogger.exportLogs()
      return new Response(exportData, {
        headers: {
          "Content-Type": "application/json",
          "Content-Disposition": `attachment; filename="error-logs-${new Date().toISOString().split("T")[0]}.json"`,
        },
      })
    }

    return NextResponse.json({ logs, total: logs.length })
  } catch (error) {
    return NextResponse.json({ error: "Failed to retrieve logs" }, { status: 500 })
  }
}

export async function DELETE() {
  try {
    errorLogger.clearLogs()
    return NextResponse.json({ message: "Logs cleared successfully" })
  } catch (error) {
    return NextResponse.json({ error: "Failed to clear logs" }, { status: 500 })
  }
}

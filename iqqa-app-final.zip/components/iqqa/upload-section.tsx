"use client"

import React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import AnalysisSummary from "./analysis-summary"
import CriteriaTable from "./criteria-table"
import type { Analysis, CriteriaRow } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import { logError, logInfo, logWarn } from "@/lib/error-logger"
import { useErrorHandler } from "@/components/error-boundary"

export default function UploadSection() {
  const [file, setFile] = React.useState<File | null>(null)
  const [uploading, setUploading] = React.useState(false)
  const [progress, setProgress] = React.useState(0)
  const [analysis, setAnalysis] = React.useState<Analysis | null>(null)
  const [isEditing, setIsEditing] = React.useState(false)
  const { toast } = useToast()
  const handleError = useErrorHandler()

  const isUploadDisabled = !file || uploading

  async function handleUpload() {
    if (!file) {
      logWarn("Upload attempted without file selection")
      return
    }

    logInfo("File upload started", {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
    })

    setUploading(true)
    setProgress(0)

    const interval = setInterval(() => {
      setProgress((p) => (p < 90 ? p + 10 : p))
    }, 250)

    try {
      const form = new FormData()
      form.append("conversation", file)
      const res = await fetch("/api/analyze", { method: "POST", body: form })
      if (!res.ok) {
        const errorText = await res.text()
        throw new Error(`Failed to analyze the conversation: ${res.status} ${errorText}`)
      }
      const data = (await res.json()) as Analysis
      setAnalysis(data)
      setProgress(100)

      logInfo("File analysis completed successfully", {
        executiveName: data.executiveName,
        criteriaCount: data.criteria.length,
      })

      toast({ title: "Analysis complete", description: "Your call analysis is ready." })
    } catch (err: any) {
      logError("File upload failed", err, {
        fileName: file.name,
        fileSize: file.size,
        component: "UploadSection",
      })

      handleError(err, { fileName: file.name, fileSize: file.size })

      toast({
        title: "Upload failed",
        description: err?.message ?? "Something went wrong.",
        variant: "destructive",
      })
    } finally {
      clearInterval(interval)
      setUploading(false)
      setTimeout(() => setProgress(0), 600)
    }
  }

  function updateRow(updated: CriteriaRow) {
    if (!analysis) return

    logInfo("Criteria row updated", {
      criteriaId: updated.id,
      criteria: updated.criteria,
      newWeightage: updated.weightage,
    })

    setAnalysis({
      ...analysis,
      criteria: analysis.criteria.map((r) => (r.id === updated.id ? updated : r)),
    })
  }

  async function handleSave() {
    if (!analysis) {
      logWarn("Save attempted without analysis data")
      return
    }

    logInfo("Analysis save started", {
      executiveName: analysis.executiveName,
      criteriaCount: analysis.criteria.length,
    })

    try {
      const res = await fetch("/api/save-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(analysis),
      })
      if (!res.ok) {
        const errorText = await res.text()
        throw new Error(`Failed to save analysis: ${res.status} ${errorText}`)
      }

      logInfo("Analysis saved successfully", {
        executiveName: analysis.executiveName,
      })

      toast({ title: "Saved", description: "Your analysis was saved successfully." })
      setIsEditing(false)
    } catch (err: any) {
      logError("Analysis save failed", err, {
        executiveName: analysis.executiveName,
        component: "UploadSection",
      })

      handleError(err, { executiveName: analysis.executiveName })

      toast({
        title: "Save failed",
        description: err?.message ?? "Something went wrong.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex flex-col gap-4 sm:gap-6">
      <div className="grid gap-3 sm:gap-4 md:grid-cols-[1fr_auto] md:items-end">
        <div className="grid gap-2">
          <Label htmlFor="conversation" className="text-sm sm:text-base font-medium">
            Upload your conversation here :
          </Label>
          <Input
            id="conversation"
            type="file"
            accept=".mp3,.wav,.m4a,.mp4,.txt,.pdf"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="h-10 sm:h-11"
          />
        </div>
        <Button
          type="button"
          onClick={handleUpload}
          disabled={isUploadDisabled}
          className="bg-green-600 hover:bg-green-700 text-white h-10 sm:h-11 px-4 sm:px-6 text-sm sm:text-base w-full md:w-auto"
        >
          Upload
        </Button>
      </div>

      {uploading && (
        <div className="rounded-md border bg-card p-3 sm:p-4 text-sm">
          <p className="font-medium">Upload in progress.. please wait</p>
          <div className="mt-2 sm:mt-3 h-2 w-full overflow-hidden rounded bg-muted" aria-label="Upload progress">
            <div
              className="h-2 rounded bg-green-600 transition-all"
              style={{ width: `${progress}%` }}
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={progress}
            />
          </div>
        </div>
      )}

      {analysis && (
        <Card>
          <CardHeader className="pb-4 sm:pb-6">
            <CardTitle className="text-base sm:text-lg md:text-xl">Detailed analysis of your call</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 sm:space-y-6">
            <AnalysisSummary
              executiveName={analysis.executiveName}
              callDuration={analysis.callDuration}
              totalWeightage={analysis.criteria.reduce((sum, row) => sum + row.weightage, 0)}
              editable={isEditing}
              onChange={(next) => setAnalysis((a) => (a ? { ...a, ...next } : a))}
            />

            <div className="space-y-2 sm:space-y-3">
              <h3 className="text-sm sm:text-base font-semibold">Analyzed Summary Of The Conversation</h3>
              <CriteriaTable rows={analysis.criteria} editable={isEditing} onRowChange={updateRow} />
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2 sm:gap-3 pt-2 sm:pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditing((v) => !v)}
                className="h-10 sm:h-11 px-4 sm:px-6 text-sm sm:text-base order-2 sm:order-1"
              >
                {isEditing ? "Stop Editing" : "Edit"}
              </Button>
              <Button
                type="button"
                onClick={handleSave}
                className="bg-green-600 hover:bg-green-700 text-white h-10 sm:h-11 px-4 sm:px-6 text-sm sm:text-base order-1 sm:order-2"
              >
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

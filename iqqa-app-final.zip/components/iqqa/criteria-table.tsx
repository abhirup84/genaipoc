"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import type { CriteriaRow } from "@/lib/types"
import { cn } from "@/lib/utils"

export default function CriteriaTable({
  rows,
  editable,
  onRowChange,
}: {
  rows: CriteriaRow[]
  editable: boolean
  onRowChange: (row: CriteriaRow) => void
}) {
  const totalWeightage = rows.reduce((sum, row) => sum + row.weightage, 0)

  return (
    <div className="overflow-x-auto -mx-2 sm:mx-0 rounded-md border">
      <div className="min-w-full inline-block align-middle">
        <Table className="min-w-[600px] sm:min-w-full">
          <TableHeader>
            <TableRow>
              <TableHead className="w-[45%] sm:w-[55%] text-xs sm:text-sm font-semibold px-2 sm:px-4 py-3">
                Call quality criteria
              </TableHead>
              <TableHead className="w-[30%] sm:w-[25%] text-xs sm:text-sm font-semibold px-2 sm:px-4 py-3">
                Proposed Category
              </TableHead>
              <TableHead className="w-[25%] sm:w-[20%] text-right text-xs sm:text-sm font-semibold px-2 sm:px-4 py-3">
                Proposed Weightage
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row) => {
              const categoryColor = row.category === "Fatal" ? "text-red-600" : "text-teal-700"
              return (
                <TableRow key={row.id}>
                  <TableCell className="px-2 sm:px-4 py-2 sm:py-3">
                    <span className="text-foreground font-normal text-xs sm:text-sm leading-relaxed">
                      {row.criteria}
                    </span>
                  </TableCell>

                  <TableCell className="px-2 sm:px-4 py-2 sm:py-3">
                    <span className={cn("font-medium text-xs sm:text-sm", categoryColor)}>{row.category}</span>
                  </TableCell>

                  <TableCell className="text-right px-2 sm:px-4 py-2 sm:py-3">
                    {editable ? (
                      <Input
                        inputMode="numeric"
                        type="number"
                        min={0}
                        value={row.weightage}
                        onChange={(e) => onRowChange({ ...row, weightage: Number(e.target.value) })}
                        aria-label="Proposed Weightage"
                        className="text-right h-8 sm:h-9 w-16 sm:w-20 text-xs sm:text-sm"
                      />
                    ) : (
                      <span className="text-foreground text-xs sm:text-sm font-medium">{row.weightage}</span>
                    )}
                  </TableCell>
                </TableRow>
              )
            })}
            <TableRow className="border-t-2 border-gray-300 bg-gray-50/80">
              <TableCell className="font-semibold px-2 sm:px-4 py-3 text-xs sm:text-sm">Total</TableCell>
              <TableCell className="px-2 sm:px-4 py-3"></TableCell>
              <TableCell className="text-right font-bold text-sm sm:text-lg px-2 sm:px-4 py-3 text-green-700">
                {totalWeightage}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

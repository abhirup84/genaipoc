"use client"
import { Label } from "@/components/ui/label"

export default function AnalysisSummary({
  executiveName,
  callDuration,
  totalWeightage,
  editable,
  onChange,
}: {
  executiveName: string
  callDuration: string
  totalWeightage: number
  editable: boolean
  onChange: (next: { executiveName?: string; callDuration?: string }) => void
}) {
  const getResultDisplay = () => {
    if (totalWeightage >= 34 && totalWeightage <= 36) {
      return { emoji: "😊", color: "text-yellow-500" }
    } else if (totalWeightage >= 30 && totalWeightage <= 33) {
      return { emoji: "😐", color: "text-amber-500" }
    } else {
      return { emoji: "😢", color: "text-red-500" }
    }
  }

  const result = getResultDisplay()

  return (
    <div className="grid gap-3 sm:gap-4 sm:grid-cols-3">
      <div className="grid gap-1.5">
        <Label className="text-muted-foreground text-xs sm:text-sm">
          Name of the Executive:{" "}
          <span className="font-medium text-foreground text-sm sm:text-base">{executiveName}</span>
        </Label>
      </div>
      <div className="grid gap-1.5">
        <Label className="text-muted-foreground text-xs sm:text-sm">
          Call Duration: <span className="font-medium text-foreground text-sm sm:text-base">{callDuration}</span>
        </Label>
      </div>
      <div className="grid gap-1.5">
        <Label className="text-muted-foreground text-xs sm:text-sm">
          Result: <span className={`font-medium text-2xl sm:text-3xl ${result.color}`}>{result.emoji}</span>
        </Label>
      </div>
    </div>
  )
}
